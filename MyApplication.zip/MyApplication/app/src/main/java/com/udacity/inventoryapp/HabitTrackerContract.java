package com.udacity.inventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.BaseColumns;

import java.util.Calendar;

/**
 * Created by nloc on 8/9/2016.
 */

public class HabitTrackerContract {

    private HabitDBHelper mDbHelper;
    Context context;
    //Data repository
    SQLiteDatabase db;

    public HabitTrackerContract(Context ctx) {
        context = ctx;
    }

    /* Inner class define table contents */
    public static abstract class HabitEntry implements BaseColumns {
        public static final String TABLE_NAME = "habit";
        public static final String COLUMN_NAME_ID = "id";
        public static final String COLUMN_NAME_CREATE_DATE = "created";
        public static final String COLUMN_NAME_TYPE = "type";
        public static final String COLUMN_NAME_DURATION = "duration";
    }

    /*
    * Open the habit database. If it can not be opened, try to create a new instance of the database,
    * If it can not be created, throws an exception to signal the failure.
    * */
    public HabitTrackerContract open() throws SQLException {
        mDbHelper = new HabitDBHelper(context);
        //Get data repository in write mode
        db = mDbHelper.getWritableDatabase();
        return this;
    }

    /*
    * Create a new habit entry using the type and duration provided.
    * if created successfully, return the new rowId for that one, otherwise return -1
    * */
    public long createNewHabit(String type, int duration) {
        Calendar currentDay = Calendar.getInstance();

        // Create a new map of values, where column names are the keys
        ContentValues initialValues = new ContentValues();
        initialValues.put(HabitEntry.COLUMN_NAME_CREATE_DATE, currentDay.toString());
        initialValues.put(HabitEntry.COLUMN_NAME_TYPE, type);
        initialValues.put(HabitEntry.COLUMN_NAME_DURATION, duration);
        return db.insert(HabitEntry.TABLE_NAME, null, initialValues);
    }

    /*
    * Delete all rows in the database
    * */
    public int deleteAllHabit() {
        //Passing null to whereClause will delete all rows.
        //To remove all rows and get a count pass "1" as the whereClause
        return db.delete(HabitEntry.TABLE_NAME, "1", null);
    }

    /*
    * Database reading
    * */
    public Cursor fetchHabitEntry(long rowId) throws SQLException {
        // Define a projection that specifies which columns from the database
        // you will actually use after this query.
        String[] projection = {
                HabitEntry._ID,
                HabitEntry.COLUMN_NAME_CREATE_DATE,
                HabitEntry.COLUMN_NAME_TYPE,
                HabitEntry.COLUMN_NAME_DURATION,

        };
        String selection = HabitEntry.COLUMN_NAME_ID + "=" + rowId;
        Cursor cursor =
                db.query(true, HabitEntry.TABLE_NAME, projection, selection, null, null, null, null, null);
        if (cursor != null) {
            cursor.moveToFirst();
        }
        return cursor;
    }

    /*
    * Database update
    * */
    public boolean updateHabitEntry(long rowId, int duration) {
        ContentValues updateValues = new ContentValues();
        updateValues.put(HabitEntry.COLUMN_NAME_DURATION, duration);
        String selection = HabitEntry.COLUMN_NAME_ID + "=" + rowId;
        return db.update(HabitEntry.TABLE_NAME, updateValues, selection, null) > 0;
    }
}